<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/fontawesome.min.css">
      <title>footer</title>
    <style>
        body{
            margin:0;
            padding: 0;

        }
       
        .footer{

            display: flex;
            justify-content: space-around;
        }
        .group3{
          
            padding: 10px;
            width: 33%;
            background-color: rgb(4, 91, 91); 
            
           
            
        }
        .group3 h2{
            color:white;
            text-align: center;
        }
        .group3 p{
            color:white;
            text-align: justify;
        }
        .group3 .link{
            padding:8px;
            font-size: 18px;
            font-weight: bold;
            text-align: center;
        }
       .group3 .link a{
            text-decoration: none;
            padding:5px;
            color:white;
            

       }
     .group3 .link a:hover{
        color:rgb(4, 91, 91); 
        background-color: white;
        border-radius: 4px;
        border:1px solid white;

       }
       .group3 .add{
        text-align: center;
       }
       .group3 .add input{
        text-align:center;
        padding:10px;
        border-style: none;
        border-radius: 4px;
        width: 50%;
 
       }
       .group3 .add span input{
        background-color: rgb(4, 91, 91); 
        color:white;
        border: 1px solid white;
        font-weight: bold;
        font-family: 'Times New Roman', Times, serif;
        font-size: 14px;
        width: 20%;
        padding:7px
       }
       .group3 .add span input:hover{
        color:rgb(4, 91, 91); 
        background-color: white;
        
       }
       .group3 .add .btn{
        padding: 10px;
        display: flex;
        align-items: center;
        font-size: 30px;
        justify-content: center;
       }
       .btn a{
        color:white;
       }
       .btn i{
        margin:10px;
        
       }
       .btn i:hover{
        background-color: white;
        color:rgb(4, 91, 91); 
        padding:5px;
       }
        
    </style>
</head>
<body>
     
     
    <div class="footer">

            <div class="group3">
                <h2 style="font-size: 40px;">Travel Atomation System</h1>
                
        
            </div>

            <div class="group3">
                <h2>Company</h1>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officia sint nihil illum ut totam, adipisci deleniti placeat accusamus nam quam atque. <br>Iure eaque esse, vero est nisi quos fugit asperiores sequi ipsa nobis fuga eum nesciunt pariatur, quod ab qui tempore in consectetur magni labore alias. Illo commodi quo provident.
            </p>
        
            </div>
            <div class="group3">
                <h2>Quick Link</h1>
                <div class="link"><a href="">Home</li></a></div>
                <div class="link"><a href="about.html">About</li></a></div>
                <div class="link"><a href="contact.html">Contact</li></a></div>
                <div class="link"> <a href="enquiry.html">Enquiry</li></a></div>
                 
            </div>

            <div class="group3">
                <h2 style="text-align: left; margin-left: 50px;">Subscribe</h1>
                <div class="add">
                    <input type="email" placeholder="Enter your email"> <span><input type="submit" value="Subscribe"></span>
                <div class="btn">
                    <a href=""><i class="fa-brands fa-whatsapp"></i></a>
                    <a href=""><i class="fa-brands fa-facebook"></i></a>
                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                </div>
                </div>

            </div>
    </div>
    

  
</body>
</html>