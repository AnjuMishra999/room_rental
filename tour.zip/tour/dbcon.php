<?php 
$server= "localhost";
$user = "root";
$password = "";
$db="tour";

$con= mysqli_connect($server,$user,$password,$db);

if($con){
 //echo "connected";
}else{

   
}

?>