<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>header page</title>
    <style>
        body{
            margin: 0;
            padding: 0;
            background-size: cover;
        }
        .container{
            margin: 0;
            padding:20px;
            display: flex;
            padding: 0px 10px;
            justify-content: space-between;
            background-color: rgb(4, 91, 91); ;
           
            
        }
        .tour{
            color:white; 
           
            
        }.tour span{
            color:rgb(5, 148, 148); 
            font-size: 50px;
        }

        ul{
           
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap:15px;
            margin-right: 10px;
            list-style: none;

        }
        ul li a{
            text-decoration: none;
            font-size: 20px;
            font-weight: bold;
            padding: 10px;
            border: 1px solid white;
            border-radius: 5px;
            color:white;

        }
        ul li a:hover{
            background-color: white;
            color:rgb(4, 91, 91); 
        }
        

    </style>
</head>
<body>
    <div class="container">
        <h1 class="tour"><span>T</span>ravel <span>A</span>tomation <span>S</span>ystem</h1>
        <ul>
            <li><a href="">Home</a> </li>
            <li><a href="about.php">About</a></li>
            <li><a href="packages.php">Package</a></li>
            <li><a href="enquiry.php">Enquiry</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="register.php">Register</a></li>
        </ul>
    </div>
    <div class="body">

    </div>
</body>
</html>