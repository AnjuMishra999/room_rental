
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>about</title>
    <style>
        body{
            margin: 0;
            padding:0;

        }
        .container{
            padding: 10px;
           

        }
        .container h1{
            text-align: center;
            font-size: 50px;
            margin-bottom: 20px;
            color: rgb(26, 95, 95);
        }
        .group{
            padding:  20px;
            display: flex;
            
            
        }
        .group1{
            background-image: url(buses/41.jpg);
            background-size: cover;
            height: 500px;
            width: 49%;
            padding: 10px;
        }
        .group2{
        
            width:49%;
            padding: 20px;
            text-align: justify;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>About Us</h1>
        <div class="group">
            <div class="group1">

            </div>
            <div class="group2">
             <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis cum laborum explicabo corporis ratione velit minus ipsam sit sed accusamus, eveniet necessitatibus reiciendis aut at magni harum facilis voluptate asperiores possimus dolores dolor culpa! Obcaecati, quos. Voluptatibus molestias ullam eveniet voluptatum debitis expedita sit ipsa vel provident optio porro laboriosam libero quam sapiente maiores necessitatibus exercitationem et, odit perspiciatis repudiandae quia ex possimus. <br><br>Asperiores eveniet magni eligendi blanditiis veritatis delectus deserunt explicabo? Exercitationem mollitia quo iure eos saepe consectetur. Autem optio nesciunt, vero ab sunt ut odio totam quas rem, commodi consequatur, libero illum? Tempore eum recusandae nisi praesentium, eos voluptate maxime similique exercitationem iusto enim illum consequuntur nam dolore quidem obcaecati deserunt consectetur hic voluptatem magnam. Autem perspiciatis iste totam quod voluptatem odio voluptatum expedita quas omnis amet pariatur ab placeat ex unde veniam similique quam harum, rerum quo maiores ipsa. <br><br>Illum aliquam quos quisquam molestias facilis asperiores nihil eaque impedit sit ea! Iusto cumque adipisci atque corrupti sapiente? Ullam dolor quibusdam cum voluptas, impedit blanditiis aliquam error, eum voluptatum ratione reiciendis eveniet? Quibusdam, provident? Assumenda nam illo voluptates labore sed cupiditate temporibus eum alias tempore veniam! Nobis voluptas possimus cupiditate unde hic? Dignissimos ipsum placeat repellendus? Consequuntur, ipsam!
             </p>
            </div>
        </div>
    </div>
</body>
</html>