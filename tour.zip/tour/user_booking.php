<?php
session_start();


if(!isset($_SESSION['email'])){
    echo " <script> alert('you are logout'); </script> ";
    header('location:index.php');
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view users</title>
    <style>
        body{
            margin:0;
            padding: 0;
        }
        .container{
        
           padding:10px;
           margin-top: 20px;
           
        }
        h1{
            text-align: center;
            color:rgb(29, 118, 118)
        }
        table{
    
            width: 100%;
            color:white;
            background-color: rgb(40, 91, 91);
            font-size: 18px;
           text-align: center;
           padding: 10px;
           

        }
        table th{
            background-color: indianred;
            
        }
    </style>
</head>
<body>
    <div class="container">
    <a style="text-decoration:none; color:rgb(4, 91, 91); font-family:'Times New Roman', Times, serif;gap:20px;font-weight:bold; font-size:20px;" href="user_index.php"><i class="fa-solid fa-house-chimney"></i>  Home </a>
        <h1> View Booking</h1>

        <table  cellpadding="17" cellspacing="1">
            <tr>
                <th>Id</th>
                <th>Name </th>
                <th>Email </th>
                <th>Location</th>
                <th>Mobile No.</th>
                <th>No.of Person</th>
                <th>Through</th>
                <th>Date</th>
                <th>Time</th>
                <th>Pack Name</th>
                
                
            </tr>
           <?php
               include 'dbcon.php';
   

               $semail=$_SESSION['email'];
               $query = "SELECT * from booking where email='$semail' " ;

               $result= mysqli_query($con, $query);
               $totalbooking = mysqli_num_rows($result);
                echo "<b>Total booking<b>"."  ".$totalbooking;
               if($result){
                
               //print_r($result);
               
               while($row = mysqli_fetch_assoc($result)){

                  
            ?>
            <tr>
                <td><?php echo $row['id'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['email'] ?></td>
                <td><?php echo $row['location'] ?></td>
                <td><?php echo $row['mobile'] ?></td>
                <td><?php echo $row['person'] ?></td>
                <td><?php echo $row['through'] ?></td>
                <td><?php echo $row['date'] ?></td>
                <td><?php echo $row['time'] ?></td>
                <td><?php echo $row['pack_name'] ?></td>
                
            </tr>
                
               <?php
                 
               }

               }
               else{
                die("quiry failed");
               }
           
           ?>

            

            
        </table>
    </div>
    
</body>
</html>