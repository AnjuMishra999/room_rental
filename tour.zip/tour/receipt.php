<?php
session_start();
 
if(!isset($_SESSION['email'])){
    echo " <script> alert('you are logout'); </script> ";
    header('location:index.php');
}
$email = $_SESSION['email'];
  //echo $email;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <style>
        body{
            margin: 0;
        }

        .container{
            margin-bottom: 10px;
            padding: 10px;

        }
        .card h1{
            margin:0px;
            align-items: center;
        }
        .group{
        
            margin-top:100px;
            display: flex;
            gap:10px;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
        }
        .group1{
            
            width: 20%;
        
        }
        .card{
            border-style: none;
            height: 450px;
            box-shadow: 0 0 7px 0px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap:0px;
            padding: 10px;
            margin-bottom: 15px;
        }
        .card img{
            width: 100%;
            
        }
        
        
        .card p{
            margin-top: 4px;
            font-size: 16px;
            margin-bottom: 4px;

        }
        .card .btn{
            margin-top: 22px;
            font-size: 17px;
            
        }
        .card .btn a{
            text-decoration: none;
            color:white; 
            padding: 5px;
            font-weight: bold;
            border-radius: 2px;
            
        }
        .btn #edit{
            background-color: rgb(4, 91, 91);
        }
        .btn #del{
            background-color:indianred;
        }
       .btn #edit:hover{
             background-color: white;
             color:rgb(4, 91, 91); ;
             border:1px solid rgb(4, 91, 91);     
            
        }
        .btn #del:hover{
            background-color: white;
            color:indianred;
            border:1px solid indianred;
        }
    </style>
</head>
<body>
<?php
         include 'dbcon.php';

         $payquery ="select * from payment";
         $payresult = mysqli_query($con,$payquery);
         $payrow = mysqli_fetch_assoc($payresult);
         //echo $payrow['pay_mode']."<br>";
         $mode = $payrow['pay_mode'];
         
      $bookquery = "SELECT * FROM booking ORDER BY id DESC";
      $bookresult = mysqli_query($con, $bookquery);
    //  if($result){ echo "connected";}
      $bookrow= mysqli_fetch_assoc($bookresult);
    //  echo $bookrow['pack_name']."<br>";
      $bname = $bookrow['name'];
      $bemail = $bookrow['email'];
      $bloc = $bookrow['location'];
      $bmob = $bookrow['mobile'];
      $bthr = $bookrow['through'];
      $nper = $bookrow['person'];
      $bdat = $bookrow['date'];
      $btim = $bookrow['time'];
      $bpack = $bookrow['pack_name'];
      //echo $nper."<br>";

    $packquery = "select * from add_package where pack_name='$bpack'";
    $packresult = mysqli_query($con, $packquery);
     $packrow = mysqli_fetch_assoc($packresult);
     //echo $packrow['pack_status'];
     $perprice= $packrow['price_person'];
     $dayprice= $packrow['price_day'];
     $pacimg = $packrow['pack_img'];
    // echo $dayprice."<br>";
     //echo $perprice ."<br>";
    if($email){
      $totalamt = $nper*($perprice*$dayprice);
     // echo $totalamt."<br>";
      if($totalamt>=10000){
        $dis = ($totalamt*10)/100;
        $amt= $totalamt-$dis;
      //  echo $amt;
      }
    }
    ?>

    <div class="container">
        
        <div class="group">
            
            <div class="group1">
              <div class="card">
                <h1>Receipt</h1>
                <h3><?php echo $bpack; ?></h3>
              <a href="buses/10.jpg"><img src="buses/<?php echo $pacimg; ?>" alt="Card image" height="60px"></a>
              <p>Name:  <?php echo $bname; ?></p>
              <p>Email:<?php echo $bemail; ?></p>
              <p>Mobile No.:<?php echo $bmob; ?></p>
              <p>Location: <?php echo $bloc; ?></p>
              <p>Date:<?php echo $bdat; ?></p>
              <p >Time:<?php echo $btim; ?></p>
              <p>Discount 10% if more than 10000</p>

              <p>Total Amount: <?php echo $amt; ?></p>
               <p>Mode: <span><?php echo $mode; ?></span></p>
              
              <div class="btn">
                <a href="" id="edit">Download</a> | <a href="" id="del">Cancel</a>
              </div>
              
              </div>
            </div>

            
           


              


              

        </div>
    </div>
        </div>
    
</body>
</html>