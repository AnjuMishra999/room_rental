<?php
session_start();
 
if(!isset($_SESSION['firs'])){
    echo " <script> alert('you are logout'); </script> ";
    header('location:index.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home page</title>
   
   <style>
    body{
        background-image: url(buses/19.jpg);
        background-size: cover;
    }
    .container3{

    height: 900px;
    width: 100%;
    }
.container{
   margin: 0;
   padding:20px;
   display: flex;
   padding: 0px 10px;
   justify-content: space-between;
   background-color: transparent;
    
   
   
}
.container h1{
    color:rgb(199, 141, 149);
}
.container span{
    color:white;
}

.container3 .tour{
  
   width: 50%;
   margin:30px;
   text-align: center;
}
.tour{
   color:white; 
   font-size: 80px;
  
   
}.tour span{
   color:rgb(199, 141, 149);
   font-size: 120px;
}

ul{
  
   display: flex;
   justify-content: flex-end;
   align-items: center;
   gap:15px;
   margin-right: 10px;
   list-style: none;

}
ul li a{
   text-decoration: none;
   font-size: 20px;
   font-weight: bold;
   padding: 10px;
   
   border-radius: 5px;
   color:white;

}
ul li a:hover{
   background-color: white;
   color:rgb(137, 80, 89);
}
.footer{

   display: flex;
   justify-content: space-around;
   }
   .group3{

   padding: 10px;
   width: 33%;
   background-color: rgb(137, 80, 89);



   }
   .group3 h2{
   color:white;
   text-align: center;
   }
   .group3 p{
   color:white;
   text-align: justify;
   }
   .group3 .link{
   padding:8px;
   font-size: 18px;
   font-weight: bold;
   text-align: center;
   }
   .group3 .link a{
   text-decoration: none;
   padding:5px;
   color:white;


   }
   .group3 .link a:hover{
   color:rgb(137, 80, 89);
   background-color: white;
   border-radius: 4px;
   border:1px solid white;

   }
   .group3 .add{
   text-align: center;
   }
   .group3 .add input{
   text-align:center;
   padding:10px;
   border-style: none;
   border-radius: 4px;
   width: 50%;

   }
   .group3 .add span input{
   background-color: rgb(137, 80, 89);
   color:white;
   border: 1px solid white;
   font-weight: bold;
   font-family: 'Times New Roman', Times, serif;
   font-size: 14px;
   width: 20%;
   padding:7px
   }
   .group3 .add span input:hover{
   color:rgb(137, 80, 89);
   background-color: white;

   }
   .group3 .add .btn{
   padding: 10px;
   display: flex;
   align-items: center;
   font-size: 30px;
   justify-content: center;
   }
   .btn a{
   color:white;
   }
   .btn i{
   margin:10px;

   }
   .btn i:hover{
   background-color: white;
   color:rgb(4, 91, 91); 
   padding:5px;
   }
   </style>
</head>
<body>
    <div class="container">
        <h1>Hi <span><?php echo $_SESSION['firs']; echo " "; echo $_SESSION['las'];?></span> </h1>
        <div><ul>
            <li><a href="">Home</a> </li>
            <li><a href="view_category.php">Category</a></li>
            <li><a href="view_package.php">Package</a></li>
            <li><a href="enquiry.php">Enquiry</a></li>
            <li><a href="Gallary.php">Gallary</a></li>
            <li><a href="user_profile.php">Profile</a></li>
            
        </ul></div>
    </div>
    <div class="container3">
        <h1 class="tour"><span>T</span>ravel <span>A</span>tomation <br><span>S</span>ystem</h1>
    </div>

 
    <div class="footer">

        <div class="group3">
            <h2 style="font-size: 40px;">Travel Atomation System</h1>
            
    
        </div>

        <div class="group3">
            <h2>Company</h1>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officia sint nihil illum ut totam, adipisci deleniti placeat accusamus nam quam atque. <br>Iure eaque esse, vero est nisi quos fugit asperiores sequi ipsa nobis fuga eum nesciunt pariatur, quod ab qui tempore in consectetur magni labore alias. Illo commodi quo provident.
        </p>
    
        </div>
        <div class="group3">
            <h2>Quick Link</h1>
            <div class="link"><a href="">Home</li></a></div>
            <div class="link"><a href="about.php">About</li></a></div>
            <div class="link"><a href="gallary.php">Gallary</li></a></div>
            <div class="link"> <a href="enquiry.php">Enquiry</li></a></div>
             
        </div>

        <div class="group3">
            <h2 style="text-align: left; margin-left: 50px;">Subscribe</h1>
            <div class="add">
                <input type="email" placeholder="Enter your email"> <span><input type="submit" value="Subscribe"></span>
            <div class="btn">
                <a href=""><i class="fa-brands fa-whatsapp"></i></a>
                <a href=""><i class="fa-brands fa-facebook"></i></a>
                <a href=""><i class="fa-brands fa-instagram"></i></a>
            </div>
            </div>

        </div>
</div>


</body>
</html>