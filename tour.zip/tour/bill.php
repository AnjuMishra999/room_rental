<?php
session_start();
 
if(!isset($_SESSION['email'])){
    echo " <script> alert('you are logout'); </script> ";
    header('location:index.php');
}
$email = $_SESSION['email'];
  //echo $email;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bill</title>
    <style>
        body{
            margin: 0;
        }

        .container{
            margin-bottom: 10px;
            padding: 10px;

        }
        .card h1{
            margin:0px;
            align-items: center;
        }
        .group{
        
            margin-top:100px;
            display: flex;
            gap:10px;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
        }
        .group1{
            
            width: 20%;
        
        }
        .card{
            border-style: none;
            height: 300px;
            box-shadow: 0 0 7px 0px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap:0px;
            padding: 10px;
            margin-bottom: 15px;
        }
        .card img{
            width: 100%;
            
        }
        
        
        .card p{
            margin-top: 4px;
            font-size: 16px;
            margin-bottom: 4px;

        }
        .card .btn{
            margin-top: 22px;
            font-size: 17px;
            
        }
        .card .btn a{
            text-decoration: none;
            color:white; 
            padding: 5px;
            font-weight: bold;
            border-radius: 2px;
            
        }
        .btn #edit{
            background-color: rgb(4, 91, 91);
        }
        .btn #del{
            background-color:indianred;
        }
       .btn #edit:hover{
             background-color: white;
             color:rgb(4, 91, 91); ;
             border:1px solid rgb(4, 91, 91);     
            
        }
        .btn #del:hover{
            background-color: white;
            color:indianred;
            border:1px solid indianred;
        }
    </style>
</head>
<body>
    <?php
         include 'dbcon.php';

         $payquery ="select * from payment";
         $payresult = mysqli_query($con,$payquery);
         $payrow = mysqli_fetch_assoc($payresult);
         //echo $payrow['pay_mode']."<br>";
         $mode = $payrow['pay_mode'];
         
      $bookquery = "SELECT * FROM booking ORDER BY id DESC";
      $bookresult = mysqli_query($con, $bookquery);
    //  if($result){ echo "connected";}
      $bookrow= mysqli_fetch_assoc($bookresult);
    //echo $bookrow['pack_name']."<br>";
      $packname = $bookrow['pack_name'];
      $nperson = $bookrow['person'];
      $packname = $bookrow['pack_name'];
      //echo $packname."<br>";
     // echo $nperson;

    $packquery = "select * from add_package where pack_name='$packname'";
    $packresult = mysqli_query($con, $packquery);
     $packrow = mysqli_fetch_assoc($packresult);
     $packn = $packrow['pack_name'];
     //echo $packn;
     //echo $packrow['pack_status'];
     
     $perprice= $packrow['price_person'];
     $dayprice= $packrow['price_day'];
    // echo $dayprice."<br>";
   // echo $perprice ."<br>";
    
    if($email){
          
      $totalamt = intval($nperson)*(intval($perprice)*intval($dayprice));
    //  echo $totalamt."<br>";
      if($totalamt>=10000){
        $dis = ($totalamt*10)/100;
        //echo $dis."discount <br>";
        $amt= $totalamt-$dis;
         
       //echo $amt."<br>";
      
      }
    
}

    ?>
    <div class="container">
        
        <div class="group">
            
            <div class="group1">
              <div class="card">
                <h1>Bill</h1>
                <h3><?php echo $packname; ?></h3>
             
              <p>Amount:Rs.<?php echo $totalamt; ?></p>
              
              <p>Discount 10% if more than 10000</p>
            
              <p>Total Amount:Rs.<?php echo $amt; ?></p>
               
              
              <div class="btn">
                <a href="payment.php" id="edit">Payment</a> | <a href="" id="del">Cancel</a>
              </div>
              
              </div>
            </div>

            
           


              


              

        </div>
    </div>
        </div>
    
</body>
</html>