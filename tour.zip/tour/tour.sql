-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2024 at 12:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tour`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_category`
--

CREATE TABLE `add_category` (
  `id` int(20) NOT NULL,
  `cname` varchar(225) NOT NULL,
  `cstatus` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_category`
--

INSERT INTO `add_category` (`id`, `cname`, `cstatus`, `image`) VALUES
(6, 'Adventures', 'Available', '10.jpg'),
(7, 'Family Tour', 'Available', '19.jpg'),
(8, 'Religious Tour', 'Available', '22.jpg'),
(9, 'Special Event Tour', 'Available', '15.jpg'),
(10, 'National Park', 'Available', '16.jpg'),
(11, 'Themed Vacations', 'Available', '17.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `add_package`
--

CREATE TABLE `add_package` (
  `id` int(20) NOT NULL,
  `pack_name` varchar(255) NOT NULL,
  `pack_status` varchar(255) NOT NULL,
  `price_person` varchar(255) NOT NULL,
  `price_day` varchar(255) NOT NULL,
  `pack_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_package`
--

INSERT INTO `add_package` (`id`, `pack_name`, `pack_status`, `price_person`, `price_day`, `pack_img`) VALUES
(2, 'Adventure In India', 'Available', '100', '1000', '2.jpg'),
(3, 'Adventure In America', 'Available', '120', '1300', '65.jpg'),
(4, 'Adventure In Russia', 'Available', '130', '1400', '58.jpg'),
(5, 'Adventure In Italy', 'Available', '130', '1200', '41.jpg'),
(6, 'Family Tour', 'Available', '100', '500', '51.jpg'),
(7, 'Family Tour In Canada', 'Available', '130', '800', '45.jpg'),
(8, 'Family Tour In Italy', 'Available', '140', '900', '36.PNG'),
(9, 'Family Tour In Thailand', 'Available', '140', '900', '62.jpg'),
(10, 'Religious Tour In India', 'Available', '70', '500', '55.jpg'),
(11, 'Religious Tour In America', 'Available', '140', '1200', '61.jpg'),
(12, 'Religious Tour In Canada', 'Available', '120', '1300', '42.jpg'),
(13, 'Religious Tour In Italy', 'Available', '100', '800', '37.PNG');

-- --------------------------------------------------------

--
-- Table structure for table `add_subcategory`
--

CREATE TABLE `add_subcategory` (
  `id` int(20) NOT NULL,
  `sub_name` varchar(225) NOT NULL,
  `sub_status` varchar(225) NOT NULL,
  `sub_price` varchar(225) NOT NULL,
  `sub_img` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_subcategory`
--

INSERT INTO `add_subcategory` (`id`, `sub_name`, `sub_status`, `sub_price`, `sub_img`) VALUES
(11, 'Adventure In India', 'Available', '1000', '23.jpg'),
(12, 'Adventure In America', 'Available', '1300', '38.PNG'),
(13, 'Adventure In Russia', 'Available', '1400', '52.jpg'),
(14, 'Adventure In Italy', 'Available', '1200', '33.PNG'),
(15, 'Family Tour In India', 'Available', '500', '32.jpg'),
(16, 'Family Tour In Canada', 'Available', '800', '34.PNG'),
(17, 'Family Tour In Italy', 'Available', '900', '26.jpg'),
(18, 'Family Tour In Thailand', 'Available', '900', '35.PNG'),
(19, 'Religious Tour In India', 'Available', '500', '21.jpg'),
(20, 'Religious Tour In America', 'Available', '1200', '29.jpg'),
(21, 'Religious Tour In Canada', 'Available', '1300', '37.PNG'),
(22, 'Religious Tour In Italy', 'Available', '800', '42.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin_image`
--

CREATE TABLE `admin_image` (
  `id` int(10) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_image`
--

INSERT INTO `admin_image` (`id`, `img`) VALUES
(35, '43.jpg'),
(36, '18.jpg'),
(37, '18.jpg'),
(38, '18.jpg'),
(39, '55.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin_register`
--

CREATE TABLE `admin_register` (
  `id` int(50) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(30) NOT NULL,
  `cpassword` varchar(30) NOT NULL,
  `mobile` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_register`
--

INSERT INTO `admin_register` (`id`, `name`, `email`, `password`, `cpassword`, `mobile`) VALUES
(1, 'Admin', 'admin@gmail.com', 'admin', 'admin', '3384904838'),
(2, 'admin', 'admin@gmail.com', 'admin', 'admin', '3384904838'),
(3, 'admin2', 'admin2@gmail.com', 'admin2', 'admin2', '2345677785');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(10) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `person` varchar(30) NOT NULL,
  `through` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` time(6) NOT NULL,
  `pack_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `name`, `email`, `location`, `mobile`, `person`, `through`, `date`, `time`, `pack_name`) VALUES
(58, 'akshat', 'akshat@gmail.com', 'vrindavan', '3883939202', '2', 'train', '0000-00-00', '10:54:00.000000', 'Adventure In India'),
(59, 'akshat', 'akshat@gmail.com', 'bihar', '2345677785', '2', 'train', '2003-02-25', '02:52:00.000000', 'Adventure In America'),
(60, 'anju', 'anjumishra@gmail.com', 'bihar', '', '10', 'Bus', '0000-00-00', '01:00:00.000000', 'Adventure In India'),
(61, 'akshat', 'akshat@gmail.com', 'Gkp', '2345677785', '6', 'train', '2003-04-24', '10:00:00.000000', 'Family Tour'),
(62, 'Anju Mishra', 'anjumishra@gmail.com', 'Gkp', '9428894847', '10', 'train', '0000-00-00', '10:54:00.000000', 'Adventure In Italy'),
(63, 'Anju Mishra', 'anjumishra@gmail.com', 'Gkp', '9428894847', '10', 'train', '0000-00-00', '10:54:00.000000', 'Adventure In Italy'),
(64, 'Anju Mishra', 'anjumishra@gmail.com', 'vrindavan', '2345677785', '6', 'train', '0000-00-00', '02:52:00.000000', 'Adventure In America'),
(65, 'anju', '', '', '', '6', '', '0000-00-00', '00:00:00.000000', 'Family Tour in India'),
(66, '', '', '', '', '', '', '0000-00-00', '00:00:00.000000', ''),
(67, 'radha', 'radha@gmail.com', 'vrindavan', '3883939202', '2', 'Bus', '0000-00-00', '10:00:00.000000', 'Adventure In America'),
(68, '', '', '', '', '', '', '0000-00-00', '00:00:00.000000', ''),
(69, '', '', '', '', '', '', '0000-00-00', '00:00:00.000000', 'Adventure In Russia'),
(70, 'radha', 'radha@gmail.com', 'bihar', '2345677785', '2', 'Bus', '2009-04-26', '10:00:00.000000', 'Adventure In Italy'),
(71, 'krishna', 'radha@gmail.com', 'lucknow', '3384904838', '4', 'car', '2004-03-25', '01:00:00.000000', 'Family Tour In Canada');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `id` int(20) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `enquiry` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`id`, `name`, `email`, `enquiry`) VALUES
(11, 'anju', 'anjumishra@gmail.com', 'how many days can you travel.'),
(12, 'Anju Mishraa', 'anjumishra@gmail.com', 'Holidays tour is available or not.');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `feedback` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `feedback`) VALUES
(1, 'akshat chaturvedi', 'akshat@gmail.com', 'very nice trip.');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(20) NOT NULL,
  `pay_email` varchar(225) NOT NULL,
  `pay_amt` varchar(225) NOT NULL,
  `pay_mode` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `pay_email`, `pay_amt`, `pay_mode`) VALUES
(1, 'anjumishra@gmail.com', '120000', 'ofline'),
(2, 'akshat@gmail.com', '18000', 'online'),
(3, '', '', ''),
(4, 'radha@gmail.com', '280800', 'ofline'),
(5, 'radha@gmail.com', '374400', 'of');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(10) NOT NULL,
  `first` varchar(30) NOT NULL,
  `last` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `cpass` varchar(255) NOT NULL,
  `mobile` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `first`, `last`, `email`, `pass`, `cpass`, `mobile`) VALUES
(7, 'anju', 'mishra', 'anjumishra@gmail.com', 'anju', 'anju', '3883939202'),
(8, 'akshat', 'chaturvedi', 'akshat@gmail.com', 'akshat', 'akshat', '2653736837'),
(9, 'Ashish', 'mishra', 'ashish@gmail.com', 'ashish', 'ashish', '2345677785'),
(10, 'Radha', 'Krishna', 'radha@gmail.com', 'radha', 'radha', '6748479440'),
(11, '', '', '', 'aa', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_category`
--
ALTER TABLE `add_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_package`
--
ALTER TABLE `add_package`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_subcategory`
--
ALTER TABLE `add_subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_image`
--
ALTER TABLE `admin_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_register`
--
ALTER TABLE `admin_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_category`
--
ALTER TABLE `add_category`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `add_package`
--
ALTER TABLE `add_package`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `add_subcategory`
--
ALTER TABLE `add_subcategory`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `admin_image`
--
ALTER TABLE `admin_image`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `admin_register`
--
ALTER TABLE `admin_register`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
