<?php 
include ('../dbcon.php');

session_start();
 
if(!isset($_SESSION['name'])){
    echo " <script> alert('you are logout'); </script> ";
    header('location:../index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin_home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/fontawesome.min.css">
    <link rel="stylesheet" href="css/ad_ind_style.css">
    <style>
    body{
    margin:0;
}
.container{
    display: flex;
    width: 100%;  
}
.group1{
    height: 800px;
    width: 16%;
    background-color: rgb(26, 108, 108);  
}
.subgroup1{
    display: flex;
    flex-direction: column;
}
.subgroup1 a{
    text-decoration: none;
    text-align: justify;
    color:white;
    font-weight: bold;
    font-size: 18px;
    padding: 15px;
    margin-right: 20px;
    
}
.subgroup1 i{
    margin-right:10px;
}

.subgroup1 .menu a{
    text-decoration: none;
    text-align: justify;
    color:white;
    font-weight: bold;
    font-size: 18px;
    padding: 15px;       
   
}
.subgroup1 .menu{
    float: right;
}
 #dash ~ .subgroup1 a{
  
  transform: translateX(0 );
}

.subgroup1 .menu:hover{
    color:rgb(26, 108, 108);
    background-color: white;
    box-shadow: 0 0 4px 1px black;
}
.subgroup1 .menu1:hover{
    color:rgb(26, 108, 108);
    background-color: white;
} 
.subgroup1 .menu2:hover{
    color:rgb(26, 108, 108);
    background-color: white;
} 
.subgroup1 .menu3:hover{
    color:rgb(26, 108, 108);
    background-color: white;
} 
.subgroup1 .menu4:hover{
    color:rgb(26, 108, 108);
    background-color: white;
}
 .subgroup1 .menu5:hover{
    color:rgb(26, 108, 108);
 
    background-color: white;
} .subgroup1 .menu6:hover{
    color:rgb(26, 108, 108);
    background-color: white;
}
 .subgroup1 .menu7:hover{
    color:rgb(26, 108, 108);
    background-color: white;
} 
.subgroup1 .menu8:hover{
    color:rgb(26, 108, 108);
    background-color: white;
} 
.subgroup1 .menu9:hover{
    color:rgb(26, 108, 108);
    background-color: white;
}
.subgroup1 .menu10:hover{
    color:rgb(26, 108, 108);
    background-color: white;
}

.group2{
    height: 800px;
    width: 86%;
    background-color:white ;
 }
.group3{

    height: 60px;
    width: 100%;
    color:white;
    display: flex;
    align-items: center;
    gap:6px;
    background-color:rgb(26, 108, 108) ;

}
.group3 .head1{
    padding: 10px;
    width: 65%;
    
}
.group3 .head2{
   
    width: 35%;
    height: 60px;
    padding: 6px;
    color:white;
    font-size: 22px;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap:10px;
}
.head2 i{
    margin-right: 10px;
}
.head2 p{
    padding: 5px 0px;
}
.head2 p a{
    text-decoration: none;
    width: 20%;
    padding:0px;
    font-size: 14px;
    color: white;
}

.head2 p a:hover{
    color:white;
    background-color: rgb(150, 100, 100);
    padding: 7px 3px;
}
.group4{
    height: 600px;
    width:99%;
    color:white;
    font-weight: bold;
    text-align: center;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    padding: 10px;
    
}
.group4 .div1{
    border-style: none;
    background-color: rgb(150, 100, 100);
    height: 200px;
    width: 30%;
    margin:10px;
    text-decoration: none;
    color:white;
    font-size: 30px;
    display: flex;
    flex-direction: column;
    gap:10px;
    justify-content: center;
    align-items: center;
}
.group4 .div1:hover{
    background-color: white;
    color: rgb(150, 100, 100);
    border: 1px solid  rgb(150, 100, 100);
}
.group4 .div2{
    border-style: none;
    background-color: rgb(150, 100, 100);
    height: 200px;
    width: 30%;
    margin:10px;
    text-decoration: none;
    color:white;
    font-size: 30px;
    display: flex;
    flex-direction: column;
    gap:10px;
    justify-content: center;
    align-items: center;
    
    
}
.group4 .div2:hover{
    background-color: white;
    color: rgb(150, 100, 100);
    border: 1px solid  rgb(150, 100, 100);
}
.group4 .div3{
    border-style: none;
    background-color: rgb(150, 100, 100);
    height: 200px;
    width: 30%;
    margin:10px;
    text-decoration: none;
    color:white;
    font-size: 30px;
    display: flex;
    flex-direction: column;
    gap:10px;
    justify-content: center;
    align-items: center;
}
.group4 .div3:hover{
    background-color: white;
    color: rgb(150, 100, 100);
    border: 1px solid  rgb(150, 100, 100);
}
.group4 .div4{
    border-style: none;
    background-color: rgb(150, 100, 100);
    height: 200px;
    width: 30%;
    margin:10px;
    text-decoration: none;
    color:white;
    font-size: 30px;
    display: flex;
    flex-direction: column;
    gap:10px;
    justify-content: center;
    align-items: center;
}
.group4 .div4:hover{
    background-color: white;
    color: rgb(150, 100, 100);
    border: 1px solid  rgb(150, 100, 100);
}
.group4 .div5{
    border-style: none;
    background-color: rgb(150, 100, 100);
    height: 200px;
    width: 30%;
    margin:10px;
    text-decoration: none;
    color:white;
    font-size: 30px;
    display: flex;
    flex-direction: column;
    gap:10px;
    justify-content: center;
    align-items: center;
}
.group4 .div5:hover{
    background-color: white;
    color: rgb(150, 100, 100);
    border: 1px solid  rgb(150, 100, 100);
}
.group4 .div6{
    border-style: none;
    background-color: rgb(150, 100, 100);
    height: 200px;
    width: 30%;
    margin:10px;
    text-decoration: none;
    color:white;
    font-size: 30px;
    display: flex;
    justify-content: center;
    align-items: center;display: flex;
    flex-direction: column;
    gap:10px;
    justify-content: center;
    align-items: center;
}
.group4 .div6:hover{
    background-color: white;
    color: rgb(150, 100, 100);
    border: 1px solid  rgb(150, 100, 100);
}
.group4 .div7{
    border-style: none;
    background-color: rgb(150, 100, 100);
    height: 200px;
    width: 30%;
    margin:10px;
    text-decoration: none;
    color:white;
    font-size: 30px;
    display: flex;
    flex-direction: column;
    gap:10px;
    justify-content: center;
    align-items: center;
}
.group4 .div7:hover{
    background-color: white;
    color: rgb(150, 100, 100);
    border: 1px solid  rgb(150, 100, 100);
}
.group4 .div8{
    border-style: none;
    background-color: rgb(150, 100, 100);
    height: 200px;
    width: 30%;
    margin:10px;
    text-decoration: none;
    color:white;
    font-size: 30px;
    display: flex;
    flex-direction: column;
    gap:10px;
    justify-content: center;
    align-items: center;
}
.group4 .div8:hover{
    background-color: white;
    color: rgb(150, 100, 100);
    border: 1px solid  rgb(150, 100, 100);
}
.group4 .div9{
    border-style: none;
    background-color: rgb(150, 100, 100);
    height: 200px;
    width: 30%;
    margin:10px;
    text-decoration: none;
    color:white;
    font-size: 30px;
    display: flex;
    flex-direction: column;
    gap:10px;
    justify-content: center;
    align-items: center;
}
.group4 .div9:hover{
    background-color: white;
    color: rgb(150, 100, 100);
    border: 1px solid  rgb(150, 100, 100);
}
    </style>
</head>
<body>

<?php
               
               $query = "SELECT * from enquiry";

               $result= mysqli_query($con, $query);
               $totalenquiry = mysqli_num_rows($result);
              // echo $totalenquiry;

               $query = "SELECT * from register";

               $result= mysqli_query($con, $query);
               $totaluser = mysqli_num_rows($result);
               //echo $totaluser;

               $query = "SELECT * from add_category";

               $result= mysqli_query($con, $query);
               $totalcat = mysqli_num_rows($result);
              // echo $totalcat;

               $query = "SELECT * from add_subcategory";

               $result= mysqli_query($con, $query);
               $totalsubcat = mysqli_num_rows($result);
               //echo $totalsubcat;

               $query = "SELECT * from add_package";

               $result= mysqli_query($con, $query);
               $totalpack = mysqli_num_rows($result);
              // echo $totalpack;
                
               $query = "SELECT * from booking";

               $result= mysqli_query($con, $query);
               $totalbook = mysqli_num_rows($result);
              // echo $totalbook;
            ?>
    <div class="container">
    <div class="group1">
                <div class="subgroup1">
               <span> <a href="" class="menu"><i id="dash" class="fa-solid fa-bars" ></i></a></span>
                <a href="" class="menu1">Dashboard</a>
                <a href="add_category.php" class="menu2"><i class="fa-solid fa-rectangle-list"></i>Add Category</a>
                <a href="add_subcategory.php" class="menu3"><i class="fa-solid fa-rectangle-list"></i>Add SubCategory</a>
                <a href="add_package.php" class="menu4"><i class="fa-solid fa-folder"></i>Add Package</a>
                <a href="view_category.php" class="menu5"><i class="fa-solid fa-list"></i>view Category</a>
                <a href="view_subcategory.php" class="menu6"><i class="fa-solid fa-list"></i>View SubCategory</a>
                <a href="view_package.php" class="menu7"><i class="fa-solid fa-folder"></i>View Package</a>
                <a href="view_user.php" class="menu7"><i class="fa-solid fa-folder"></i>View Users</a>
                <a href="view_booking.php" class="menu7"><i class="fa-solid fa-folder"></i>View Booking</a>
                <a href="manage_enquiry.php" class="menu9"><i class="fa-solid fa-file"></i>Manage Equiry</a>
                
            </div>
                   
              
        </div>
                   
              
        <div class="group2">
            <div class="group3">
               <div class="head1">
                <h1>Travel Atomation System</h1>
               </div> 
               <div class="head2">
                <h3><i class="fa-solid fa-user"></i>Welcome Adminstrator</h3>
                <p><a href="admin_profile.php">Admin Profile</a></p>
                
               </div>
            </div>
       
            <div class="group4">
               
                <a href="../admin/add_category.php" class="div1"><i class="fa-solid fa-rectangle-list"></i>Add Category</a>
                <a href="../admin/add_subcategory.php" class="div2"><i class="fa-solid fa-rectangle-list"></i>Add SubCategory</a>
                <a href="../admin/add_package.php" class="div3"><i class="fa-solid fa-folder"></i>Add Package</a>
                <a href="../admin/view_category.php" class="div4"><i class="fa-solid fa-folder"></i>View Category <br><?php echo " ". $totalcat; ?></a>
                <a href="../admin/view_subcategory.php" class="div5"><i class="fa-solid fa-folder"></i>View SubCategory <br><?php echo " ". $totalsubcat; ?></a>
                <a href="../admin/view_package.php" class="div6"><i class="fa-solid fa-folder"></i> View Packages <br> <?php echo " ". $totalpack; ?></a>
                <a href="../admin/view_user.php" class="div7"> <i class="fa-solid fa-folder"></i>View Users <br><?php echo " ". $totaluser; ?></a>
                <a href="view_booking.php" class="div8"><i class="fa-solid fa-file"></i>View Booking <br><?php echo " " ?></a>
                <a href="../admin/manage_user.php" class="div9"> <i class="fa-solid fa-file"></i>Manage Enquiry <br><?php echo " ". $totalenquiry; ?><br> </a>
            </div>
        </div>
        
    </div>
    
</body>
</html>