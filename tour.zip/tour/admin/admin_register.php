<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <style>
        body{
            margin: 0;
            background-color: white;
            height: 700px;
            font-family: 'Times New Roman', Times, serif;
            display: flex;
            justify-content: center;
            align-items: center;
            color: black;

        } 
        .container{
            box-shadow: 0px 0px 9px 2px;
            border:none;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 15px;
            height: 470px;
            width: 27%;
        }
        .head{
            margin-top: 10px;
            text-align: center;
            margin-bottom: 10px;
            padding: 10px;
            font-size: 20px;
            font-weight: bold;
            color:rgb(6, 90, 90);
        }
        hr.left{
            width: 42%;
            float:left;
            margin-right:10px;
        }
        hr.right{
            width: 46%;
            margin-left: 0px;
            float: left;
        }
        span.or{
            padding-right: 4px;
            float: left;
        }
        .items{
            margin-top: 5px;
            padding:10px;

        }
        .items label{
    
            font-weight: bold;
            
        }
        .items input{
            margin-top:5px;
            padding: 10px;
            width: 95%;
        }
        .name{
            display: flex;
            gap:20px;
        }
        .name input{
            width: 90%;
        }
        .term{
            text-align: center;

        }
        p span{
            color: rgb(29, 135, 177) ;
            font-weight: bold;
        }
        .button{
            text-align: center;
            
        }
        .button input{
            padding: 5px;
            background-color:rgb(4, 91, 91);
            width: 100%;
            font-weight: bold;
            font-family: 'Times New Roman', Times, serif;
            color: white;
            font-size: 20px;
            border: none;
        }
        .button input:hover{
            border: 1px solid rgb(4, 91, 91);
            color:rgb(4, 91, 91);;
            background-color: white;
        }
        .term a{
            text-decoration: none;
            color:rgb(4, 91, 91);
            
        }
        .term a:hover{
            
            background-color: rgb(4, 91, 91);
            border: 1px solid rgb(4, 91, 91);
            color:white;
            padding:4px;
        
        }
    </style>
</head>
<body>
 
<?php 
    
    include '../dbcon.php' ;
    
    if(isset($_POST['submit'])){
        $name = mysqli_real_escape_string($con, $_POST['name']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $pass = mysqli_real_escape_string($con, $_POST['password']);
        $cpass = mysqli_real_escape_string($con, $_POST['cpassword']);
        $mobile = mysqli_real_escape_string($con, $_POST['contact']);
        

        $emailquery = "select * from admin_register where email = '$email' " ;
        $query = mysqli_query($con,$emailquery);

        $emailcount = mysqli_num_rows($query);

        if($emailcount>1){
            echo "<script> alert('email is already exists'); </script> ";
        }
        else{
            if($pass=== $cpass)
            {
              $insertquery= "insert into admin_register(`name`, `email`, `password`, `cpassword`, `mobile`) values('$name','$email','$pass','$cpass','$mobile')";

              $query= mysqli_query($con,$insertquery);

              if($query){
                        ?>
                            <script>
                                alert("Inserted Successful");
                            </script>
                            
                        <?php
                        
                        }else{
                        ?>
                            <script>
                            alert("Not inserted");
                            </script>
                        <?php
                        }
                        
                        

            }else{
                
                ?>
                <script>alert("password are not matching");</script>
                <?php
            }
        }


    }
    ?>
    
    <div class="container">
    <a style="text-decoration:none; color:rgb(4, 91, 91);margin-top:20px; font-family:'Times New Roman', Times, serif;gap:20px;font-weight:bold; font-size:20px;" href="admin_index.php"><i class="fa-solid fa-house-chimney"></i>  Home </a>
        <div class="head"> Admin Sign </div>

     <div class="draw">
        <hr class="left"> <span class="or">OR</span> <hr class="right">
     </div>
     <form action="" method="POST"> 
     <div class="items name">
        <span><label for="name">Name</label><br>
            <input type="text" name="name" placeholder="John Doe"></span>
            <span><label for="email">Email</label><br>
            <input type="email" name="email" placeholder="abc@gmail.com"></span>
      </div>
      
      <div class="items name">
        <span><label for="password">Password</label><br>
        <input type="password" name="password" placeholder="Must be atleast 6 characters">
      </span>
        <span><label for="cpassword">Confirm Password</label><br>
        <input type="password" name="cpassword" id="cpassword" placeholder="Must be atleast 6 characters"></span>
      </div>
      <div class="items ">
        <label for="contact">Mobile No.</label><br>
        <input type="text" name="contact" id="contact" placeholder="+91xxxxxxxx">
      </div>

      <p>By signing up, you agree to our <span>Terms and Conditions.</span></p>
      
      <div class="button">
        <input type="submit" name="submit" value="Sign Up">
      </div>

      <p class="term">Already registered? <span><a href="admin_login.php">Login</a></span></p>
     </form>
    </div>
</body>
</html>