<?php 
include ('../dbcon.php');

session_start();
 
if(!isset($_SESSION['name'])){
    echo $_SESSION['email'];
    echo " <script> alert('you are logout'); </script> ";
    header('location:../index.php');
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin profile</title>
    <style>
        body{
            margin:0;
            margin-top:10px;
            display: flex;
            justify-content: center;
            align-content: center;

        }
        .container{
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.9);
            width: 50%;
            height:600px ;
        }
        .container h1{
            text-align: center;
            color: rgb(150, 100, 100); 
        }
        .header{
            background-color: rgb(150, 100, 100);
            padding: 10px;
            display: flex;
            align-content: center;
        }
        .header .head1{
    
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-content: center;
        }
        
        .head1 img{
            margin-bottom: 0px; ;
            border-radius: 50%;
            margin: 10px 50px;
            height: 300px;
            width: 300px;
            padding: 10px;
            position: relative;
        }
        .head1 label{
            padding: 6px;
            text-decoration: none;
            color:white;
            position: absolute;
            bottom:360px;
            left:725px;
            font-weight: bold;
            font-size: 30px;
        }
        .head1 input[type="file"]{
            display: none;
        }
        .head1 a:hover{
            color:white;
            background-color: transparent;
        }

        .header h1{
            margin: 0;
            color:white;
            font-size: 60px;
        }
        .header h3{
            margin: 0;
            color:white;
            font-size: 40px;
        }
        .head2{
        
            display: flex;
            flex-direction: column;
            justify-content: center;
      
        }
    
        ul{ list-style: none;
            display: flex;
            justify-content: flex-end;
            gap:20px;
            padding: 10px;
            margin:10px 0px;

        }
        .section ul li a{
            text-decoration: none;
            color:white;
            background-color:rgb(150, 100, 100); 
            padding: 10px;
            font-weight:bold;
        
        } 
           
     
   

    </style>
</head>
<body>
    <?php  
    include('../dbcon.php');
    if(isset($_POST['submit'])){
     $file_name=$_FILES['image']['name'];
     $temp_name=$_FILES['image']['tmp_name'];
     $folder = '../upload_img/'.$file_name;
   
     $result = "select * from admin_image ";
     $query = mysqli_query($con, $result);
      
     if($query){
      // echo "connected ";
      $insertquery= "insert into admin_image(`img`)values('$file_name')";
      $query= mysqli_query($con,$insertquery);
      if($query){
       echo "<script> alert(' Inserted data successfully'); </script>";
       
     }
     else{
       echo "<script> alert(' Data will not be inserted '); </script>";
     }
   
     }
     else{
       echo "notconnected";
     }
   
    }
               
     $query = "SELECT * from admin_register";

     $result= mysqli_query($con, $query);
     $row = mysqli_fetch_assoc($result);

     $imgquery = "SELECT * FROM admin_image ORDER BY id DESC";
     $imgresult = mysqli_query($con,$imgquery);
     $imgrow = mysqli_fetch_assoc($imgresult);
     $totalenquiry = mysqli_num_rows($imgresult);
     
  ?>

    
    
    <div class="container">
    <a style="text-decoration:none; color:rgb(4, 91, 91); font-family:'Times New Roman', Times, serif;gap:20px;font-weight:bold; padding:20px;font-size:20px;" href="admin_index.php"><i class="fa-solid fa-house-chimney"></i>  Home </a>
        <h1> Profile</h1>
        <div class="header">
            <div class="head1">
                <img src="../buses/<?php echo $imgrow['img'];?>" alt="" height="100px">
                <form action="" method="POST" enctype="multipart/form-data">
                <label for="plus">+</label>
                <input type="file" id="plus" name="image" require>
                <input type="submit" name="submit" value="upload img">
                </form>
            </div>
            <div class="head2">
                <h1><?php echo $row['name'];?></h1>
                <h3><?php echo $row['email'];?></h3>
            </div>
        </div>
        <div class="section">
            <ul>
                <li><a href="admin_register.php">Edit Pofile</a></li>
                <li><a href="admin_forgetpass.php">Edit Password</a></li>
                <li><a href="admin_logout.php">Logout</a></li>
            </ul>
            
            
        </div>
    </div>
</body>
</html>