<?php 
   include("../dbcon.php");
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/v_sub_style.css">
    <title>subcategory</title>
    <style>
       
        
    </style>
</head>
<body>



    <div class="container">
    <a style="text-decoration:none; color:rgb(4, 91, 91); font-family:'Times New Roman', Times, serif;gap:20px;font-weight:bold; font-size:20px;" href="admin_index.php"><i class="fa-solid fa-house-chimney"></i>  Home </a>
        <h1>Sub Category</h1>
        <div class="group">
        <?php 
   
          $result = 'select * from add_subcategory';
          $query = mysqli_query($con, $result);
          if($query){
          while($row = mysqli_fetch_assoc($query)){
            
            ?>
            <div class="group1">
              <div class="card">
                <h3><?php echo $row['sub_name'] ?></h3>
                <a href="../buses/10.jpg"><img src="../buses/<?php echo $row['sub_img'] ?>" alt="Card image" height="200px"></a>
          
              <h5>Price:<?php echo $row['sub_price'] ?>/person each days</h5>
              <p><?php echo $row['sub_status'] ?></p>
              <div class="btn">
                <a href="view_package.php" id="edit">Book Now</a> 
              </div>
              </div>
              </div>
     <?php 
    
    } 
  }else{
    die("quiry failed");
  }
    ?>  
   
        </div>
    </div>
       
    
</body>
</html>