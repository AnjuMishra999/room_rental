<?php 
include ('../dbcon.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view users</title>
    <style>
        body{
            margin:0;
            padding: 0;
        }
        .container{
        
           padding:10px;
           margin-top: 20px;
           
        }
        h1{
            text-align: center;
            color:rgb(29, 118, 118)
        }
        table{
    
            width: 100%;
            color:white;
            background-color: rgb(40, 91, 91);
            font-size: 18px;
           text-align: center;
           padding: 10px;
           

        }
        table th{
            background-color: indianred;
            
        }
    </style>
</head>
<body>
    <div class="container">
    <a style="text-decoration:none; color:rgb(4, 91, 91); font-family:'Times New Roman', Times, serif;gap:20px;font-weight:bold; font-size:20px;" href="admin_index.php"><i class="fa-solid fa-house-chimney"></i>  Home </a>
        <h1> Manage Enquiry</h1>

        <table  cellpadding="17" cellspacing="1">
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email </th>
                <th>Enquiry</th>
                
            </tr>
            <?php
               
               $query = "SELECT * from enquiry";

               $result= mysqli_query($con, $query);
               $totalrow = mysqli_num_rows($result);
               echo $totalrow;
                
               if($result){
               // print_r($result);
                
                while($row = mysqli_fetch_assoc($result)){
            ?>
            <tr>
                <td><?php echo $row['id'] ?></td>
                <td><?php echo $row['name'] ?></td>
                <td><?php echo $row['email'] ?></td>
                <td><?php echo $row['enquiry'] ?></td>
                
            </tr>
                
               <?php

                }

               }
               else{
                die("quiry failed");
               }
           
           ?>

           
        </table>
    </div>
    
</body>
</html>