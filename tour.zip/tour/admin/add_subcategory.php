<?php
 include('../dbcon.php');
 if(isset($_POST['submit'])){
  $subname = mysqli_real_escape_string($con, $_POST['subname']);
  $substatus = mysqli_real_escape_string($con, $_POST['substatus']);
  $subprice = mysqli_real_escape_string($con, $_POST['subprice']);
  $file_name=$_FILES['subimage']['name'];
  $temp_name=$_FILES['subimage']['tmp_name'];
  $folder = '../upload_img/'.$file_name;

  $result = "select * from add_subcategory ";
  $query = mysqli_query($con, $result);
   
  if($query){
   // echo "connected ";
   $insertquery= "INSERT INTO `add_subcategory`(`sub_name`, `sub_status`, `sub_price`, `sub_img`) VALUES ('$subname','$substatus','$subprice','$file_name')";
   $query= mysqli_query($con,$insertquery);
   if($query){
    echo "<script> alert(' Inserted data successfully'); </script>";
    
  }
  else{
    echo "<script> alert(' Data will not be inserted '); </script>";
  }

  }
  else{
    echo "notconnected";
  }

 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/fontawesome.min.css">
    <link rel="stylesheet" href="css/sub_style.css">
    <title>add_subcategory</title>
    <style>
      
    </style>
</head>
<body>
    <div class="container">
    <a style="text-decoration:none; color:rgb(4, 91, 91); font-family:'Times New Roman', Times, serif;gap:20px;font-weight:bold; font-size:20px;" href="admin_index.php"><i class="fa-solid fa-house-chimney"></i>  Home </a>
        <div class="head">ADD SUBCATEGORY</div>

     <div class="draw">
        <hr class="left">
        
     </div>
     <form action="" method="POST" enctype="multipart/form-data">
     <div class="items name">
        <span><label for="name">Category name</label><br>
            <input type="text" name="subname" id="name" placeholder="Adventures"></span>
        <span> <label for="status">Status</label><br>
            <input type="text" name="substatus" id="status" placeholder="available"></span>
      </div>
      <div class="items name">
        <span ><label for="price">Price</label><br>
            <input type="text" name="subprice" id="price" placeholder="price" ></span>
      <span class="image">
        <input type="file" name="subimage" id="upload" placeholder=""><br>
        <label for="upload">Upload Images <span><i class="fa-solid fa-download"></i></span></label>
      </span>
      </div>

      
      <div class="button">
        <input type="submit"  name="submit" value="ADD ">
      </div>

     </form>
    </div>
</body>
</html>