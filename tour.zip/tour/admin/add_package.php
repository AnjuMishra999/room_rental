<?php
 include('../dbcon.php');
 if(isset($_POST['submit'])){
  $packname = mysqli_real_escape_string($con, $_POST['packname']);
  $packstatus = mysqli_real_escape_string($con, $_POST['packstatus']);
  $personprice = mysqli_real_escape_string($con, $_POST['personprice']);
  $dayprice = mysqli_real_escape_string($con, $_POST['dayprice']);
  $file_name=$_FILES['packimage']['name'];
  $temp_name=$_FILES['packimage']['tmp_name'];
  $folder = '../upload_img/'.$file_name;

  $result = "select * from add_package ";
  $query = mysqli_query($con, $result);
   
  if($query){
   // echo "connected ";
   $insertquery= "INSERT INTO `add_package`(`pack_name`, `pack_status`, `price_person`, `price_day`, `pack_img`) VALUES ('$packname','$packstatus','$personprice','$dayprice','$file_name')";
   $query= mysqli_query($con,$insertquery);
   if($query){
    echo "<script> alert(' Inserted data successfully'); </script>";
   
  }
  else{
    echo "<script> alert(' Data will not be inserted '); </script>";
  }

  }
  else{
    echo "notconnected";
  }

 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/fontawesome.min.css">
    <link rel="stylesheet" href="css/pac_style.css">
    <title>add_subcategory</title>
    <style>
       
    </style>
</head>
<body>
    <div class="container">
    <a style="text-decoration:none; color:rgb(4, 91, 91); font-family:'Times New Roman', Times, serif;gap:20px;font-weight:bold; font-size:20px;" href="admin_index.php"><i class="fa-solid fa-house-chimney"></i>  Home </a>
        <div class="head">ADD PACKAGE</div>

     <div class="draw">
        <hr class="left">
        
     </div>
<form action="" method="POST" enctype="multipart/form-data">
     <div class="items name">
        <span><label for="name">Category name</label><br>
            <input type="text" name="packname" id="name" placeholder="Adventures"></span>
        <span> <label for="status">Status</label><br>
            <input type="text" name="packstatus" id="status" placeholder="available"></span>
      </div>
      <div class="items name">
        <span ><label for="price">Price/person</label><br>
            <input type="text" name="personprice" id="price" placeholder="price" ></span>
      <span ><label for="price">Price/day</label><br>
        <input type="text" name="dayprice" id="price" placeholder="price" ></span>
      </div>

      <div class="items ">
      <div class="image">
        <input type="file" name="packimage" id="upload" placeholder=""><br>
        <label for="upload">Upload Images <span><i class="fa-solid fa-download"></i></span></label>
      </div>
      </div>

      
      <div class="button">
        <input type="submit"  name="submit" value="ADD ">
      </div>
<form>
      
    </div>
</body>
</html>