<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/pac_style.css">
    <title>Package</title>
    <style>
        body{
            margin: 0;
        }

        .container{
            margin-bottom: 10px;
            padding: 10px;

        }
        .container h1{
            margin: 50px;
            text-align: center;
        }
        .group{
        
            
            display: flex;
            gap:10px;
            flex-wrap: wrap;
            justify-content: space-evenly;
        }
        .group1{
            
            width: 20%;
        
        }
        .card{
            border-style: none;
            height: 400px;
            box-shadow: 0 0 7px 0px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap:0px;
            padding: 10px;
            margin-bottom: 15px;
        }
        .card img{
            width: 100%;
            
        }
        
        .card h5{
            margin-top: 9px;
            margin-bottom: 5px;
            font-size: 16px;
        }
        .card p{
            margin-top: 0px;
            font-size: 16px;
            margin-bottom: 4px;

        }
        .card .btn{
            margin-top: 10px;
            font-size: 17px;
            
        }
        .card .btn a{
            text-decoration: none;
            color:white; 
            padding: 5px;
            font-weight: bold;
            border-radius: 2px;
            
        }
        .btn #edit{
            background-color: rgb(4, 91, 91);
        }
        .btn #del{
            background-color:indianred;
        }
       .btn #edit:hover{
             background-color: white;
             color:rgb(4, 91, 91); ;
             border:1px solid rgb(4, 91, 91);     
            
        }
        .btn #del:hover{
            background-color: white;
            color:indianred;
            border:1px solid indianred;
        }
    </style>
</head>
<body>
    <div class="container">
    <a style="text-decoration:none; color:rgb(4, 91, 91); font-family:'Times New Roman', Times, serif;gap:20px;font-weight:bold; font-size:20px;" href="admin_index.php"><i class="fa-solid fa-house-chimney"></i>  Home </a>
        <h1>Package</h1>
        <div class="group">
            <div class="group1">
              <div class="card">
                <h3>Adventures</h3>
              <a href="buses/10.jpg"><img src="buses/10.jpg" alt="Card image" height="200px"></a>
            
              <h5>Price:12000/day</h5>
              <p>Available</p>
              <p>Number of people: 5</p>
              <div class="btn">
                <a href="" id="edit">Edit</a> | <a href="" id="del">Delete</a>
              </div>
              </div>
            </div>

            
            <div class="group1">
                <div class="card">
                  <h3>Family Tours</h3>
                  <a href="buses/19.jpg"><img src="buses/19.jpg" alt="Card image" height="200px">
                  </a>
                <h5>Price:12000/day</h5>
                <p>Available</p>
                <p>Number of people: 5</p>
                <div class="btn">
                  <a href="" id="edit">Edit</a> | <a href="" id="del">Delete</a>
                </div>
                </div>
              </div>


              <div class="group1">
                <div class="card">
                  <h3>Religious Tour</h3>
                  <a href="buses/22.jpg"><img src="buses/22.jpg" alt="Card image" height="200px">
                  </a>
                <h5>Price:12000/day</h5>
                <p>Available</p>
                <p>Number of people: 5</p>
                <div class="btn">
                  <a href="" id="edit">Edit</a> | <a href="" id="del">Delete</a>
                </div>
                </div>
              </div>


              <div class="group1">
                <div class="card">
                  <h3>Special Event Tour</h3>
                  <img src="buses/15.jpg" alt="Card image" height="200px">
                  
                    <h5>Price:12000/day</h5>
                <p>Available</p>
                <p>Number of people: 5</p>
                <div class="btn">
                  <a href="" id="edit">Edit</a> | <a href="" id="del">Delete</a>
                </div>
                </div>
              </div>


              <div class="group1">
                <div class="card">
                  <h3>National Park</h3>
                  <a href="buses/16.jpg"><img src="buses/16.jpg" alt="Card image" height="200px">
                 </a>
                    <h5>Price:12000/day</h5>
                <p>Available</p>
                <p>Number of people: 5</p>
                <div class="btn">
                  <a href="" id="edit">Edit</a> | <a href="" id="del">Delete</a>
                </div>
                </div>
              </div>


              <div class="group1">
                <div class="card">
                  <h3>Themed Vacations</h3>
                  <a href="buses/17.jpg"><img src="buses/17.jpg" alt="Card image" height="200px">
                   </a>
               
                <h5>Price:12000/day</h5>
                <p>Available</p>
                <p>Number of people: 5</p>
                <div class="btn">
                  <a href="" id="edit">Edit</a> | <a href="" id="del">Delete</a>
                </div>
                </div>
              </div>


        </div>
    </div>
        </div>
    
</body>
</html>