<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallary</title>
    <style>
        body{
            margin: 0;
            padding: 0;

        }
        .container{
            padding: 10px;

            
        }
        h1{
            text-align: center;
            color:indianred;
        }
        .card{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 30px;
            height: 600px;
            box-shadow: 0 0 4px 0.3 rgba(0,0,0,0.3);
        }
        .card img{
            padding: 20px;
            margin: 10px;
            
            width: 20%;
            box-shadow: 0 0 10px  rgba(0,0,0,0.3);
            
        }
       
    </style>
</head>
<body>
    <div class="conatainer">
        <h1>Gallary</h1>
        <div class="card">
           
            <img src="buses/1.jpg" class="image" alt="" height="200px">
            <img src="buses/16.jpg" alt="" height="200px">
            <img src="buses/17.jpg" alt="" height="200px">
            <img src="buses/18.jpg" alt="" height="200px">
            <img src="buses/29.jpg" alt="" height="200px">
            <img src="buses/30.jpg" alt="" height="200px">
            <img src="buses/34.PNG" alt="" height="200px">
            <img src="buses/32.jpg" alt="" height="200px">
            <img src="buses/27.jpg" alt="" height="200px">
            <img src="buses/39.jpg" alt="" height="200px">
            <img src="buses/21.jpg" alt="" height="200px">
            <img src="buses/38.PNG" alt="" height="200px">
            <img src="buses/54.jpg" alt="" height="200px">
            <img src="buses/55.jpg" alt="" height="200px">
            <img src="buses/56.jpg" alt="" height="200px">
            <img src="buses/57.jpg" alt="" height="200px">
            <img src="buses/60.jpeg" alt="" height="200px">
            <img src="buses/61.jpg" alt="" height="200px">
            <img src="buses/28.jpg" alt="" height="200px">
           


            
        </div>
    </div>
    
</body>
</html>