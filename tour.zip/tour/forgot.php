<?php
 session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>forget</title>
    <style>
        body{
            margin: 0;
            padding: 0;
            height: 700px;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: white;
            color:black;
        }
        .container{
            box-shadow: 0px 0px 4px 2px;
            height: 230px;
            width: 25%;
           
            padding: 10px;

        }
        .container h3{
            color: rgb(23, 127, 127);
            text-align: center;
        }
        
        .left{
            width: 40%;
            float: left;

        }
        .right{
            margin-left: 0;
            width: 49%;
            float: right;
            padding-right: 2px;
        }
        #or{
            margin-left: 5px;
            margin-right: 0;
        }
        .menu{
            margin-bottom:5px;
            padding: 10px;
        
            

        }
       .menu label{
          font-weight: bold;
          margin-bottom: 5px;
          padding: 2px;
          

        }
       .menu input{
            width: 95%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 2px;
    
            border: 1px solid black;
            
        
        }
        .forget{
            
            padding: 4px;
            margin-top: 0;
            margin-right: 5px;
            text-align: right;
            font-weight: bold;
           
        }
        
        .forget a{
            text-decoration: none;
            color:rgb(23, 127, 127);
        }
        .forget a:hover{
            color: white;
            padding: 4px;
            background-color: rgb(23, 127, 127);;
        }
        .btn{
            width: 100%;
            margin-top:0;

        }
        .btn input{
            margin-top: 0;
            border-style: none;
            padding:10px;
            background-color:rgb(4, 91, 91);;
            width: 100%;
            font-size: 18px;
            font-weight: bold;
            color:white;
            font-family: 'Times New Roman', Times, serif;
        }
        .btn input:hover{
            background-color: white;
            border: 1px solid rgb(4, 91, 91);
            color:rgb(4, 91, 91);
        }
        p{
            margin-top: 4px;
          text-align: center;
        }
        p span a{
            font-weight: bold;
            color: rgb(4, 91, 91);
            text-decoration: none;
            
            
        }
        p span a:hover{
            color: white;
            background-color:rgb(4, 91, 91);
            padding: 3px;
        
            
        }
    </style>
</head>
<body>

<?php 
   
    include 'dbcon.php' ;
    
    if(isset($_POST['submit'])){
        $email = $_POST['email'];

            $email_search = " select * from register where email ='$email' ";
            $query = mysqli_query($con, $email_search);
           $row= mysqli_fetch_assoc($query);
           
           echo "<script> alert(' before connected  success '); </script>";
           if($email){
         
             echo "<script> alert('connected  success '); </script>";
              header('location:new_pass.php');
              
        }else{
            echo "<script> alert('not connected  '); </script>";
        }


        }  

        
    

    ?>

    <div class="container">
        <h3>Forget Password  </h3>
        <hr class="left"><span id="or">OR</span> <hr class="right">
        <form action="new_pass.php"  method="">
        <div class="menu">
            <label for="email">Email</label><br>
            <input type="email" id="email" name="email" placeholder="abc@gmail.com">
        </div>
        
        
        <div class="btn">
            <input type="submit" name="submit" value="Send">
        </div>
     
        </form>
    </div>
</body>
</html>