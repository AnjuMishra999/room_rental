<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/fontawesome.min.css">
   <link rel="stylesheet" type="text/css" href="css/style1.css">
   <style>
    .container{
    margin: 0;
    padding:20px;
    display: flex;
    padding: 0px 10px;
    justify-content: space-between;
    background-color: transparent;

    }.container p{
        color:white;
    }
    .container a{
        color:white;
        text-decoration: none;
    }
   </style>
</head>
<body>
    <div class="container">
        <p><a href="admin/admin_login.php"> <i class="fa-solid fa-house"></i>Admin</a> </p>
        <div><ul>
            <li><a href="">Home</a> </li>
            <li><a href="about.php">About</a></li>
            <li><a href="package.php">Package</a></li>
            <li><a href="enquiry.php">Enquiry</a></li>
            <li><a href="gallary.php">Gallary</a></li>
            <li><a href="register.php">Register</a></li>
        </ul></div>
    </div>
    <div class="container3">
        <h1 class="tour"><span>T</span>ravel <span>A</span>tomation <br><span>S</span>ystem</h1>
    </div>

 
    <div class="footer">

        <div class="group3">
            <h2 style="font-size: 40px;">Travel Atomation System</h1>
            
    
        </div>

        <div class="group3">
            <h2>Company</h1>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officia sint nihil illum ut totam, adipisci deleniti placeat accusamus nam quam atque. <br>Iure eaque esse, vero est nisi quos fugit asperiores sequi ipsa nobis fuga eum nesciunt pariatur, quod ab qui tempore in consectetur magni labore alias. Illo commodi quo provident.
        </p>
    
        </div>
        <div class="group3">
            <h2>Quick Link</h1>
            <div class="link"><a href="">Home</li></a></div>
            <div class="link"><a href="about.php">About</li></a></div>
            <div class="link"><a href="gallary.php">Gallary</li></a></div>
            <div class="link"> <a href="enquiry.php">Enquiry</li></a></div>
             
        </div>

        <div class="group3">
            <h2 style="text-align: left; margin-left: 50px;">Subscribe</h1>
            <div class="add">
                <input type="email" placeholder="Enter your email"> <span><input type="submit" value="Subscribe"></span>
            <div class="btn">
                <a href=""><i class="fa-brands fa-whatsapp"></i></a>
                <a href=""><i class="fa-brands fa-facebook"></i></a>
                <a href=""><i class="fa-brands fa-instagram"></i></a>
            </div>
            </div>

        </div>
</div>
</body>
</html>