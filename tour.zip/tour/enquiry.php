<?php
 include 'dbcon.php' ;
    
 if(isset($_POST['submit'])){
     $name = mysqli_real_escape_string($con, $_POST['uname']);
     $email = mysqli_real_escape_string($con, $_POST['email']);
     $enquiry = mysqli_real_escape_string($con, $_POST['enquiry']);
     
  

  $result = "SELECT * FROM `enquiry`";
  $query = mysqli_query($con, $result);
   
  if($query){
   // echo "connected ";
   $insertquery= "INSERT INTO `enquiry`(`name`, `email`, `enquiry`) VALUES ('$name','$email','$enquiry')";
   $query= mysqli_query($con,$insertquery);
   if($query){
    echo "<script> alert(' Inserted data successfully'); </script>";
    
  }
  else{
    echo "<script> alert(' Data will not be inserted '); </script>";
  }

  }
  else{
    echo "notconnected";
  }

 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <style>
        body{
            margin: 0;
            background-color: white;
            height: 700px;
            font-family: 'Times New Roman', Times, serif;
            display: flex;
            justify-content: center;
            align-items: center;
            color: black;

        }
        .container{
            box-shadow: 0px 0px 9px 2px;
            border:none;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 15px;
            height: 400px;
            width: 25%;
        }
        .head{
            margin-top: 10px;
            text-align: center;
            margin-bottom: 10px;
            padding: 10px;
            font-weight: bold;
            font-size: 20px;
            color:rgb(6, 90, 90);
        }
        hr.left{
            width: 42%;
            float:left;
            margin-right:10px;
        }
        hr.right{
            width: 46%;
            margin-left: 0px;
            float: left;
        }
        span.or{
            padding-right: 4px;
            float: left;
        }
        .items{
            margin-top: 5px;
            padding:10px;

        }
        .items label{
    
            font-weight: bold;
            
        }
        .items input{
            margin-top:5px;
            padding: 10px;
            width: 95%;
        }
        .name{
            display: flex;
            gap:20px;
        }
        .name input{
            width: 90%;
        }
        .term{
            text-align: center;

        }
        p span{
            color: rgb(29, 135, 177) ;
            font-weight: bold;
        }
        .button{
            text-align: center;
            
        }
        .button input{
            padding: 5px;
            background-color:rgb(4, 91, 91);
            width: 100%;
            font-weight: bold;
            font-family: 'Times New Roman', Times, serif;
            color: white;
            font-size: 20px;
            border: none;
        }
        .button input:hover{
            border: 1px solid rgb(4, 91, 91);
            color:rgb(4, 91, 91);;
            background-color: white;
        }
    </style>
</head>
<body>


    <div class="container">
        
        <div class="head">Enquiry   </div>

     <div class="draw">
        <hr class="left"> <span class="or">OR</span> <hr class="right">
     </div>
     <form action="" method="POST"> 

     <div class="items ">
       <label for="name">Name</label><br>
            <input type="text" name="uname" id="name" placeholder="John Doe">
        
      </div>
      <div class="items">
        <label for="email">Email</label><br>
        <input type="email" name="email" placeholder="abc@gmail.com">
      </div>

      <div class="items">
        <label for="enquiry">Enquiry</label><br>
        <input type="text" name="enquiry" placeholder="ask your doubt">
      </div>
     
      <div class="button">
        <input type="submit" name="submit"  value="Enquiry Now">
      </div>

      </form>
     
    </div>
</body>
</html>