<?php
 session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking</title>
    <style>
        body{
            margin: 0;
            background-color: white;
            height: 700px;
            font-family: 'Times New Roman', Times, serif;
            display: flex;
            justify-content: center;
            align-items: center;
            color: black;

        }
        .container{
            box-shadow: 0px 0px 9px 2px;
            border:none;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 15px;
            height: 570px;
            width: 27%;
        }
        .head{
            margin-top: 10px;
            text-align: center;
            margin-bottom: 10px;
            padding: 10px;
            font-size: 20px;
            font-weight: bold;
            color:rgb(6, 90, 90);
        }
        hr.left{
            width: 42%;
            float:left;
            margin-right:10px;
        }
        hr.right{
            width: 46%;
            margin-left: 0px;
            float: left;
        }
        span.or{
            padding-right: 4px;
            float: left;
        }
        .items{
            margin-top: 5px;
            padding:10px;

        }
        .items label{
    
            font-weight: bold;
            
        }
        .items input{
            margin-top:5px;
            padding: 10px;
            width: 95%;
        }
        .name{
            display: flex;
            gap:20px;
        }
        .name input{
            width: 90%;
        }
        .term{
            text-align: center;

        }
        p span{
            color: rgb(29, 135, 177) ;
            font-weight: bold;
        }
        .button{
            text-align: center;
            
        }
        .button input{
            padding: 5px;
            background-color:rgb(4, 91, 91);
            width: 100%;
            font-weight: bold;
            font-family: 'Times New Roman', Times, serif;
            color: white;
            font-size: 20px;
            border: none;
        }
        .button input:hover{
            border: 1px solid rgb(4, 91, 91);
            color:rgb(4, 91, 91);;
            background-color: white;
        }
        .term a{
            text-decoration: none;
            color:rgb(4, 91, 91);
            
        }
        .term a:hover{
            
            background-color: rgb(4, 91, 91);
            border: 1px solid rgb(4, 91, 91);
            color:white;
            padding:4px;
        
        }
    </style>
</head>
<body>
 
<?php 
    
    include 'dbcon.php' ;
    
    if(isset($_POST['submit'])){
        $name = mysqli_real_escape_string($con, $_POST['name']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $location = mysqli_real_escape_string($con, $_POST['location']);
        $mobile = mysqli_real_escape_string($con, $_POST['contact']);
        $person = mysqli_real_escape_string($con, $_POST['person']);
        $by = mysqli_real_escape_string($con, $_POST['by']);
        $date = mysqli_real_escape_string($con, $_POST['date']);
        $time = mysqli_real_escape_string($con, $_POST['time']);
        $packname = mysqli_real_escape_string($con, $_POST['packname']);
        
        $result = "select * from booking ";
  $query = mysqli_query($con, $result);

   
  if($query){
   // echo "connected ";
   $insertquery= "INSERT INTO `booking`(`name`, `email`, `location`, `mobile`, `person`, `through`, `date`, `time`, `pack_name`)VALUES('$name','$email','$location','$mobile','$person','$by','$date','$time','$packname')";

   $query= mysqli_query($con,$insertquery);
    if($query){
      echo "<script> alert(' Inserted data successfully'); </script>";
      header('location:bill.php');
    }
    else{
      echo "<script> alert(' Data will not be inserted '); </script>";
    }

  }
  else{
    echo "notconnected";
  }

 }
    
 ?>
    
    <div class="container">
    <a style="text-decoration:none; color:rgb(4, 91, 91); font-family:'Times New Roman', Times, serif;gap:20px;font-weight:bold; font-size:20px;" href="user_index.php"><i class="fa-solid fa-house-chimney"></i>  Home </a>
        <div class="head">Booking Package</div>

     <div class="draw">
        <hr class="left"> <span class="or">OR</span> <hr class="right">
     </div>
     <form action="" method="POST"> 
     <div class="items name">
        <span><label for="name">Name</label><br>
            <input type="text" name="name" placeholder="John Doe"></span>
        <span><label for="last">Email</label><br>
            <input type="email" name="email" placeholder="abc@gmail.com"></span>
      </div>
      <div class="items name">
        <span><label for="location">Location</label><br>
        <input type="text" name="location" id="location" placeholder="street/city/place near by pickup"></span>
        <span><label for="contact">Mobile No.</label><br>
        <input type="text" name="contact" id="contact" placeholder="+91xxxxxxxx"></span>
      </div>

      <div class="items name">
        <span><label for="person">No.of Person</label><br>
        <input type="text" name="person" id="person" placeholder="1/2/3/4/..."></span>
        <span><label for="by">Through</label><br>
        <input type="text" name="by" id="by" placeholder="Bus/train/..."></span>
      </div>
      <div class="items name">
        <span><label for="date">Date</label><br>
        <input type="text" name="date" placeholder="DD/MM/YYYY">
      </span>
        <span><label for="time">Time</label><br>
        <input type="text" name="time" id="time" placeholder="00:00 AM/PM"></span>
      </div>
      <div class="items">
        <label for="packname">Package Name</label><br>
        <input type="text" name="packname" placeholder="Adventures in india">
      </div>
      
      <div class="button">
        <input type="submit" name="submit" value="Sign Up">
      </div>

     </form>
    </div>
</body>
</html>